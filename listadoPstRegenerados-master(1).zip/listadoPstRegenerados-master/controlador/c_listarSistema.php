<?php
include('../modelo/pst.php');

$sistema = traerSistema();

include('../vista/listarSistema.php');
?>