<?php
include('../modelo/pst.php');

$portal = traerPortal();

include('../vista/listarPortal.php');
?>