<?php
include('../modelo/pst.php');

$municipios = traerMunicipio();

include('../vista/listarMunicipalidades.php');
?>