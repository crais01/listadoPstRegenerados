<?php
include('vista/index.php');
?>